import javax.inject.Named;
@Named
public class CategoriaBean {
    private String nombreEntidad="Samuel Gonzalez";

    public String getNombreEntidad() {
        return nombreEntidad;
    }

    public void setNombreEntidad(String nombreEntidad) {
        this.nombreEntidad = nombreEntidad;
    }
    
    
    
    
}
